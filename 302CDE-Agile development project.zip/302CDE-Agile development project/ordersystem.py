from tkinter import *
from tkinter import filedialog
import json
import datetime
import os
from decimal import Decimal
import tkinter.messagebox
from datetime import datetime
import customtkinter
from PIL import ImageTk, Image


class quanl:
    q = 0
    def localquan(self, a, pname):
        Panadol = 10000
        if a is None:
            if pname == "Panadol" and Panadol - quanl.q > 0:
                return Panadol - quanl.q

        else:
            if pname == "Panadol" and Panadol - quanl.q >= 0:
                quanl.q = quanl.q + int(a)
                return Panadol - quanl.q

            else:
                return -1

class quanf:
    q = 0
    def localquan(self, a, pname):

        Famotidine = 50000


        if a is None:

            if pname=="Famotidine" and Famotidine - quanf.q > 0 :
                return Famotidine - quanf.q

        else:
            if  pname == "Famotidine" and Famotidine - quanf.q >= 0:
                quanf.q = quanf.q + int(a)
                return Famotidine - quanf.q


            else:
                return -1

class quanc:
    q = 0
    def localquan(self, a, pname):
        Chiorpheniramin = 300
        if a is None:
            if pname == "Chiorpheniramin" and Chiorpheniramin - quanc.q > 0:
                return Chiorpheniramin - quanc.q
        else:
            if pname == "Chiorpheniramin" and Chiorpheniramin - quanc.q >= 0:
                quanc.q = quanc.q + int(a)
                return Chiorpheniramin - quanc.q
            else:
                return -1


class quanp:
    q = 0
    def localquan(self, a, pname):
        Paracetamol = 5000
        if a is None:

            if pname=="Paracetamol" and Paracetamol - quanp.q > 0 :
                return Paracetamol - quanp.q
        else:
            if pname == "Paracetamol" and Paracetamol - quanp.q >= 0:
                quanp.q = quanp.q + int(a)
                return Paracetamol - quanp.q
            else:
                return -1


def orderform():
    def showqty(*arg):
        print(Pname.get())
        lblmsg.grid(row=9)
        if Pname.get() == "Paracetamol":
            Qty = quanp.localquan(quanp.q, None, Pname.get())
            if Qty == None:
                lblmsg.configure(text="Out of Stock")
            else:
                lblmsg.configure(text="The Quantity is: %s" %Qty)

        if Pname.get() == "Chiorpheniramin":
            Qty = quanc.localquan(quanc.q, None, Pname.get())
            if Qty == None  :
                lblmsg.configure(text="Out of Stock")
            else:
                lblmsg.configure(text="The Quantity is: %s" %Qty)

        if Pname.get() == "Famotidine":
            Qty = quanf.localquan(quanf.q, None, Pname.get())
            if Qty == None  :
                lblmsg.configure(text="Out of Stock")
            else:
                lblmsg.configure(text="The Quantity is: %s" %Qty)

        if Pname.get() == "Panadol":
            Qty = quanl.localquan(quanl.q, None, Pname.get())
            if Qty == None:
                lblmsg.configure(text="Out of Stock")
            else:
                lblmsg.configure(text="The Quantity is: %s" %Qty)

    mainframe.pack_forget()
    options = ["Panadol", "Famotidine", "Chiorpheniramin", "Paracetamol"]
    orderF = customtkinter.CTkFrame(app)
    orderF.grid(row=0, pady=15, padx=100, sticky="nesw")
    selvalue = tkinter.StringVar(orderF)
    selvalue.set(options[0])#default value

    customtkinter.CTkLabel(orderF, text="Order Form", font=("Arial", 20)).grid(row=0, columnspan=2, pady=8)

    customtkinter.CTkLabel(orderF, text="Customer Name", font=("Arial", 15)).grid(row=1, pady=5, padx=5)
    Cname = customtkinter.CTkEntry(orderF)
    Cname.grid(row=1, column=1, pady=5, padx=5)
    customtkinter.CTkLabel(orderF, text="Product Name", font=("Arial", 15)).grid(row=2, pady=5, padx=5)
    Pname = customtkinter.CTkOptionMenu(orderF,values=options, variable=selvalue,command=showqty )
    Pname.grid(row=2, column=1, pady=5, padx=5)
    #
    customtkinter.CTkLabel(orderF, text="Address", font=("Arial", 15)).grid(row=3, pady=5, padx=5)
    CAddress = customtkinter.CTkEntry(orderF)
    CAddress.grid(row=3, column=1, pady=5, padx=5)
    customtkinter.CTkLabel(orderF, text="Contact No", font=("Arial", 15)).grid(row=4, pady=5, padx=5)
    CContact = customtkinter.CTkEntry(orderF)
    CContact.grid(row=4, column=1, pady=5, padx=5)
    customtkinter.CTkLabel(orderF, text="Quantity", font=("Arial", 15)).grid(row=5)
    Quan = customtkinter.CTkEntry(orderF)
    Quan.grid(row=5, column=1, pady=5, padx=5)





    def Createjson():
        if  Quan.get() == "" or Cname.get() == "" or CAddress.get() == "" or CContact.get() == "":
            lblmsg.grid(row=9)
            lblmsg.configure(text="System MSG: Please fill data required in the form.")
        else:
            if Quan.get()=="0" or CContact.get() == "0":
                lblmsg.configure(text="System MSG: The Quantity and Contact No should not be 0.")
            else:
                if  str(Quan.get()).isnumeric() and str(CContact.get()).isnumeric():
                    if Pname.get() == "Panadol":
                        lstatus = quanl.localquan(quanl.q, None, Pname.get())
                        print('Result: x' + str(lstatus) + 'x')
                        if  lstatus is None:
                            lstatus = 0
                        if lstatus <= 0 or lstatus is None :
                            lblmsg.grid(row=9)
                            lblmsg.configure(text="System MSG: The product chosen is out the stock.")
                        else:
                            if  lstatus - int(Quan.get()) <0:
                                lblmsg.grid(row=9)
                                lblmsg.configure(text="System MSG: The stock is %s." % lstatus)
                            else:
                                quanl.localquan(quanl.q, Quan.get(), Pname.get())
                                now = datetime.now()
                                s1 = now.strftime("%Y%m%d%H%M%S")
                                OrderNo = s1 + Cname.get()
                                lblmsg.grid_forget()
                                orderF.grid_forget()
                                filename = OrderNo + ".json"
                                obj = {
                                    "OrderNumber": OrderNo,
                                    "CustomerName": Cname.get(),
                                    "Address": CAddress.get(),
                                    "Contact": CContact.get(),
                                    "ProductName": Pname.get(),
                                    "Quantity": Quan.get(),
                                    "DeliveryStatus": "Not Finished",
                                    "Weight": "",
                                    "Progress": "",
                                    "Ddate": ""
                                }
                                with open("c://Database//"+filename, "w") as out_file:
                                    json.dump(obj, out_file)

                                print("order Create")
                                popup = customtkinter.CTkFrame(app)
                                popup.grid(row=0, padx=150, pady=15, sticky="N")
                                customtkinter.CTkLabel(popup, text='The order has been created.', font=("Arial", 15)).grid(row=0,
                                                                                                                      padx=15,
                                                                                                                      pady=15)
                                customtkinter.CTkButton(popup, text="Close", font=("Arial", 15),
                                                        command=lambda: [orderF.grid_forget(), popup.grid_forget(),
                                                                         mainframe.pack(pady=15, padx=15)]).grid(row=1, padx=15,
                                                                                                                 pady=15)
                    if Pname.get() == "Famotidine":
                        lstatus = quanf.localquan(quanf.q, None, Pname.get())
                        print('Result: x' + str(lstatus) + 'x')
                        if  lstatus is None:
                            lstatus = 0
                        if lstatus <= 0 or lstatus is None :
                            lblmsg.grid(row=9)
                            lblmsg.configure(text="System MSG: The product chosen is out the stock.")
                        else:
                            if  lstatus - int(Quan.get()) <0:
                                lblmsg.grid(row=9)
                                lblmsg.configure(text="System MSG: The stock is %s." % lstatus)
                            else:
                                quanf.localquan(quanf.q, Quan.get(), Pname.get())
                                now = datetime.now()
                                s1 = now.strftime("%Y%m%d%H%M%S")
                                OrderNo = s1 + Cname.get()
                                lblmsg.grid_forget()
                                orderF.grid_forget()
                                filename = OrderNo + ".json"
                                obj = {
                                    "OrderNumber": OrderNo,
                                    "CustomerName": Cname.get(),
                                    "Address": CAddress.get(),
                                    "Contact": CContact.get(),
                                    "ProductName": Pname.get(),
                                    "Quantity": Quan.get(),
                                    "DeliveryStatus": "Not Finished",
                                    "Weight": "",
                                    "Progress": "",
                                    "Ddate": ""
                                }
                                with open("c://Database//"+filename, "w") as out_file:
                                    json.dump(obj, out_file)

                                print("order Create")
                                popup = customtkinter.CTkFrame(app)
                                popup.grid(row=0, padx=150, pady=15, sticky="N")
                                customtkinter.CTkLabel(popup, text='The order has been created.', font=("Arial", 15)).grid(
                                    row=0,
                                    padx=15,
                                    pady=15)
                                customtkinter.CTkButton(popup, text="Close", font=("Arial", 15),
                                                        command=lambda: [orderF.grid_forget(), popup.grid_forget(),
                                                                         mainframe.pack(pady=15, padx=15)]).grid(row=1,
                                                                                                                 padx=15,
                                                                                                                 pady=15)
                    if Pname.get() == "Chiorpheniramin":
                        lstatus = quanc.localquan(quanc.q, None, Pname.get())
                        print('Result: x' + str(lstatus) + 'x')
                        if  lstatus is None:
                            lstatus = 0
                        if lstatus <= 0 or lstatus is None :
                            lblmsg.grid(row=9)
                            lblmsg.configure(text="System MSG: The product chosen is out the stock.")
                        else:
                            if  lstatus - int(Quan.get()) <0:
                                lblmsg.grid(row=9)
                                lblmsg.configure(text="System MSG: The stock is %s." % lstatus)
                            else:
                                quanc.localquan(quanc.q, Quan.get(), Pname.get())
                                now = datetime.now()
                                s1 = now.strftime("%Y%m%d%H%M%S")
                                OrderNo = s1 + Cname.get()
                                lblmsg.grid_forget()
                                orderF.grid_forget()
                                filename = OrderNo + ".json"
                                obj = {
                                    "OrderNumber": OrderNo,
                                    "CustomerName": Cname.get(),
                                    "Address": CAddress.get(),
                                    "Contact": CContact.get(),
                                    "ProductName": Pname.get(),
                                    "Quantity": Quan.get(),
                                    "DeliveryStatus": "Not Finished",
                                    "Weight": "",
                                    "Progress": "",
                                    "Ddate": ""
                                }
                                with open("c://Database//"+filename, "w") as out_file:
                                    json.dump(obj, out_file)

                                print("order Create")
                                popup = customtkinter.CTkFrame(app)
                                popup.grid(row=0, padx=150, pady=15, sticky="N")
                                customtkinter.CTkLabel(popup, text='The order has been created.', font=("Arial", 15)).grid(
                                    row=0,
                                    padx=15,
                                    pady=15)
                                customtkinter.CTkButton(popup, text="Close", font=("Arial", 15),
                                                        command=lambda: [orderF.grid_forget(), popup.grid_forget(),
                                                                         mainframe.pack(pady=15, padx=15)]).grid(row=1,
                                                                                                                 padx=15,
                                                                                                             pady=15)
                    if Pname.get() == "Paracetamol":
                        lstatus = quanp.localquan(quanp.q, None, Pname.get())
                        print('Result: x' + str(lstatus) + 'x')
                        if  lstatus is None:
                            lstatus = 0
                        if lstatus <= 0 or lstatus is None :
                            lblmsg.grid(row=9)
                            lblmsg.configure(text="System MSG: The product chosen is out the stock.")
                        else:
                            if  lstatus - int(Quan.get()) <0:
                                lblmsg.grid(row=9)
                                lblmsg.configure(text="System MSG: The stock is %s." % lstatus)
                            else:
                                quanp.localquan(quanp.q, Quan.get(), Pname.get())
                                now = datetime.now()
                                s1 = now.strftime("%Y%m%d%H%M%S")
                                OrderNo = s1 + Cname.get()
                                lblmsg.grid_forget()
                                orderF.grid_forget()
                                filename = OrderNo + ".json"
                                obj = {
                                    "OrderNumber": OrderNo,
                                    "CustomerName": Cname.get(),
                                    "Address": CAddress.get(),
                                    "Contact": CContact.get(),
                                    "ProductName": Pname.get(),
                                    "Quantity": Quan.get(),
                                    "DeliveryStatus": "Not Finished",
                                    "Weight": "",
                                    "Progress": "",
                                    "Ddate": ""
                                }
                                with open("c://Database//"+filename, "w") as out_file:
                                    json.dump(obj, out_file)

                                print("order Create")
                                popup = customtkinter.CTkFrame(app)
                                popup.grid(row=0, padx=150, pady=15, sticky="N")
                                customtkinter.CTkLabel(popup, text='The order has been created.', font=("Arial", 15)).grid(
                                    row=0,
                                    padx=15,
                                    pady=15)
                                customtkinter.CTkButton(popup, text="Close", font=("Arial", 15),
                                                        command=lambda: [orderF.grid_forget(), popup.grid_forget(),
                                                                         mainframe.pack(pady=15, padx=15)]).grid(row=1,
                                                                                                                 padx=15,
                                                                                                                 pady=15)
                else:
                    lblmsg.grid(row=9)
                    lblmsg.configure(text="System MSG: The Quantity and Contact No should contain number only.")
            # R = quan.localquan(quan.q,Quan.get())
            # print('Resault: x' +str(R)+'x')

    customtkinter.CTkButton(orderF, text="Create Order", command=Createjson).grid(row=8, column=0, pady=15, padx=5)
    customtkinter.CTkButton(orderF, text="Back", command=lambda: [orderF.grid_forget(), lblmsg.grid_forget(),
                                                                  mainframe.pack(pady=15, padx=15)]).grid(row=8,
                                                                                                          column=1,
                                                                                                          pady=15,
                                                                                                          padx=5)

    msgbox = LabelFrame(orderF, text="System Message", labelanchor=N, font=("Arial", 15)).grid(row=9, columnspan=2)
    lblmsg = customtkinter.CTkLabel(msgbox, text="")


def showjson():
    name = filedialog.askopenfilename(initialdir="C:\Database", filetypes={ ("JSON", "*.json")})
    if name =="": #cancel select file
        orderstatus()
    else:
        with open(name, "r") as reader:
            targetfile = json.loads(reader.read())

        showframe = customtkinter.CTkFrame(app)
        showframe.pack(pady=15, padx=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 17), text="Order Detail").grid(row=0, columnspan=2, padx=5,
                                                                                        pady=10)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Order No.:").grid(row=1, column=0, padx=5, pady=5,
                                                                                      sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["OrderNumber"]).grid(row=1, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Customer Name:").grid(row=2, column=0, padx=5,
                                                                                          pady=(5, 5),
                                                                                          sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["CustomerName"]).grid(row=2, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Contact:").grid(row=3, column=0, padx=5, pady=5,
                                                                                    sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Contact"]).grid(row=3, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Product Name:").grid(row=4, column=0, padx=5,
                                                                                         pady=5,
                                                                                         sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["ProductName"]).grid(row=4, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Quantity:").grid(row=5, column=0, padx=5, pady=5,
                                                                                     sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Quantity"]).grid(row=5, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Delivery Status:").grid(row=6, column=0, padx=5,
                                                                                            pady=5,
                                                                                            sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["DeliveryStatus"]).grid(row=6, column=1)
        customtkinter.CTkButton(showframe, text="Back", command=lambda: [showframe.pack_forget(), orderstatus()]).grid(
            row=7, column=0, columnspan=2, pady=15, padx=15)


def orderstatus():
    mainframe.pack_forget()
    osframe = customtkinter.CTkFrame(app)
    osframe.pack(pady=15, padx=15)
    orderLabel = customtkinter.CTkLabel(osframe, text='Please Choose the Order file to review', font=("Arial", 17))
    orderLabel.grid(row=0, pady=15, padx=15, sticky=S)
    customtkinter.CTkButton(osframe, font=("Arial", 15), text='Open the File',
                            command=lambda: [osframe.pack_forget(), showjson()]).grid(row=1, column=0, pady=15, padx=15,
                                                                                      sticky=S)
    customtkinter.CTkButton(osframe, font=("Arial", 15), text='Back to Menu',
                            command=lambda: [mainframe.pack(pady=15, padx=5), osframe.pack_forget()]).grid(row=2,
                                                                                                           sticky=S,
                                                                                                           pady=15,
                                                                                                           padx=15)


customtkinter.set_appearance_mode("System")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green
global app
app = customtkinter.CTk()
app.geometry("500x600")
app.iconbitmap("./jmmy.ico") # pls find the file path
app.title("JMMY Ordering System")
mainframe = customtkinter.CTkFrame(app)
mainframe.pack(pady=15, padx=15)
logo = ImageTk.PhotoImage(Image.open("./jmmy.ico")) # pls find the file path

lblimage = Label(mainframe, image=logo)
lblimage.grid(row=0, pady=15, padx=15)
title = customtkinter.CTkLabel(mainframe, text="Welcome to JMMY Ordering System", font=("Arial", 17))
title.grid(row=1, pady=15, padx=15, sticky=S)
sendbutton = customtkinter.CTkButton(mainframe, font=("Arial", 15), text="Create Order", command=orderform)
sendbutton.grid(row=2, column=0, pady=15, padx=15, sticky=S)
receive = customtkinter.CTkButton(mainframe, font=("Arial", 15), text="Order Status", command=lambda: [orderstatus()])
receive.grid(row=3, sticky=S, pady=15, padx=15)
exitButton = customtkinter.CTkButton(mainframe, font=("Arial", 15), text="Exit", command=app.quit)
exitButton.grid(row=4, sticky=S, pady=15, padx=15)

app.mainloop()
##start the GUI
