from tkinter import *
from tkinter import filedialog
import json
import os
from decimal import Decimal
import tkinter.messagebox
from datetime import date
import customtkinter
from PIL import ImageTk, Image




def manacourier():
    mcframe = customtkinter.CTkFrame(app)
    mcframe.pack( pady=15, padx=15)
    orderLabel= customtkinter.CTkLabel(mcframe, text='Please Choose the courier for manage', font=("Arial", 17))
    orderLabel.grid(row=0, pady=15, padx=15, sticky=S)
    customtkinter.CTkButton(mcframe, font=("Arial", 15), text='Open the File', command=lambda: [courierform(),mcframe.pack_forget()]).grid(row=1, column = 0,  pady=15, padx=15,sticky=S)
    customtkinter.CTkButton(mcframe, font=("Arial", 15), text='Back to Menu', command=lambda: [mainframe.pack(pady=15, padx=5), mcframe.pack_forget()]).grid(row=2, sticky=S,  pady=15, padx=15)
    lblmsg = customtkinter.CTkLabel(mcframe,text="",font=("Arial", 15) )

    def courierform():
        fname = filedialog.askopenfilename(initialdir="c:/Database", filetypes={("JSON", "*.json")})
        if fname =="":
            manacourier()
        else:
            with open(fname, "r") as reader:
                targetfile = json.loads(reader.read())
                lblmsg.grid_forget()
                mcframe.pack_forget()
                courierform2(targetfile)



    def courierform2(targetfile):

            courierframe = customtkinter.CTkFrame(app)
            courierframe.pack(pady=15, padx=5)
            customtkinter.CTkLabel(courierframe, font=("Arial", 17), text="Courier Detail").grid(row=0, columnspan=2, padx=5,
                                                                                            pady=10)
            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text="Delivery No.:").grid(row=1, column=0, padx=5, pady=5,
                                                                                          sticky=W)
            dnum = customtkinter.CTkLabel(courierframe, font=("Arial", 15), text=targetfile["OrderNumber"]).grid(row=1, column=1)
            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text="Customer Name:").grid(row=2, column=0, padx=5, pady=5,
                                                                                              sticky=W)
            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text=targetfile["CustomerName"]).grid(row=2, column=1)
            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text="Address:").grid(row=3, column=0, padx=5, pady=5,
                                                                                        sticky=W)
            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text=targetfile["Address"]).grid(row=3, column=1)
            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text="Contact:").grid(row=4, column=0, padx=5, pady=5,
                                                                                        sticky=W)
            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text=targetfile["Contact"]).grid(row=4, column=1)

            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text="Weight:").grid(row=5, column=0, padx=5, pady=5,
                                                                                             sticky=W)
            Dweight = customtkinter.CTkEntry(courierframe)
            Dweight.grid(row=5,column=1 )
            Dweight.insert(0, targetfile["Weight"])
            svalue = customtkinter.StringVar(value=targetfile["Progress"])


            customtkinter.CTkLabel(courierframe, font=("Arial", 15), text="Process:").grid(row=6, column=0, padx=5, pady=5,
                                                                                             sticky=W)

            Dprogress = customtkinter.CTkOptionMenu(courierframe, values=["Collection","Delivery","Retention","Complete Delivery"], variable=svalue)
            Dprogress.grid(row=6, column=1, pady=5, padx=5)



            customtkinter.CTkButton(courierframe, text="Update",command=lambda: [Updatejson()] ).grid(row=7, column=0)
            customtkinter.CTkButton(courierframe, text="Back", command=lambda: [courierframe.pack_forget(),manacourier()]).grid(row=7, column=1)
            lblfmsg = customtkinter.CTkLabel(courierframe, text=" ", font=("Arial", 15))
            lblfmsg.grid(row=8, columnspan=2, padx=10,pady=10)


            def Updatejson():
                result = Dweight.get()
                if result == "":
                    lblfmsg.configure(text="Please input weight")
                    return
                else:
                    if str(result).isnumeric():
                        if int(result) <= 0 :
                            lblfmsg.configure(text="Weight should be greater than 0")
                            return
                        else:
                            if Dprogress.get()=="":
                                lblfmsg.configure(text="Please select the delivery process")
                            else:
                                filename = targetfile["OrderNumber"] + ".json"
                                if Dprogress.get() == "Complete Delivery":
                                    Dstatus = "Finished"
                                else:
                                    Dstatus = "Not Finished"

                                obj = {

                                    "OrderNumber": targetfile["OrderNumber"],
                                    "CustomerName": targetfile["CustomerName"],
                                    "Address": targetfile["Address"],
                                    "Contact": targetfile["Contact"],
                                    "ProductName": targetfile["ProductName"],
                                    "Quantity": targetfile["Quantity"],
                                    "Ddate": str(date.today()),
                                    "Progress": Dprogress.get(),
                                    "Weight": Dweight.get(),
                                    "DeliveryStatus": Dstatus
                                }  ##Creat json string
                                with open("c://Database//"+filename, "w") as out_file:
                                    json.dump(obj, out_file)  ##Create json file

                                print("Courier update")
                                courierframe.pack_forget()
                                popup = customtkinter.CTkFrame(app, width=300)
                                popup.pack(padx=30, pady=15)
                                customtkinter.CTkLabel(popup, text='The order has been updated.', font=("Arial", 15)).grid(
                                    row=0,
                                    padx=15,
                                    pady=15)
                                customtkinter.CTkButton(popup, text="Close", font=("Arial", 15),
                                                        command=lambda: [popup.pack_forget(),
                                                                         mainframe.pack(pady=15, padx=15)]).grid(row=1,
                                                                                                                 padx=15,
                                                                                                                 pady=15)
                    else:
                        lblfmsg.configure(text="The weight is not number.Please Check!")
                    return


def showjson():
    name = filedialog.askopenfilename(initialdir="C:\Database", filetypes={ ("JSON", "*.json")})
    if name =="":
        checktatus()
    else:
        with open(name, "r") as reader:
            targetfile = json.loads(reader.read())
        showframe = customtkinter.CTkFrame(app)
        showframe.pack(pady=15, padx=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 17), text="Courier Detail").grid(row=0, columnspan=2, padx=5,
                                                                                          pady=10)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Delivery No.:").grid(row=1, column=0, padx=5,
                                                                                         pady=5,
                                                                                         sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["OrderNumber"]).grid(row=1, column=1,
                                                                                                   padx=5, pady=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Customer Name:").grid(row=2, column=0, padx=5,
                                                                                          pady=5,
                                                                                          sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["CustomerName"]).grid(row=2, column=1,
                                                                                                    padx=5, pady=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Address:").grid(row=3, column=0, padx=5, pady=5,
                                                                                    sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Address"]).grid(row=3, column=1, padx=5,
                                                                                               pady=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Contact:").grid(row=4, column=0, padx=5, pady=5,
                                                                                    sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Contact"]).grid(row=4, column=1, padx=5,
                                                                                               pady=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Weight:").grid(row=5, column=0, padx=5, pady=5,
                                                                                   sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Weight"]).grid(row=5, column=1, padx=5,
                                                                                              pady=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Progress:").grid(row=6, column=0, padx=5, pady=5,
                                                                                     sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Progress"]).grid(row=6, column=1, padx=5,
                                                                                                pady=5)

        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Last Update:").grid(row=7, column=0, padx=5, pady=5,
                                                                                        sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Ddate"]).grid(row=7, column=1, padx=5,
                                                                                             pady=5)
        customtkinter.CTkButton(showframe, text="Back", command=lambda: [showframe.pack_forget(), checktatus()]).grid(
            row=8, column=0, columnspan=2, pady=15, padx=15)


def checktatus():
    mainframe.pack_forget()
    csframe = customtkinter.CTkFrame(app )
    csframe.pack(pady=15, padx=15)
    orderLabel= customtkinter.CTkLabel(csframe, text='Please Choose the courier to review', font=("Arial", 17))
    orderLabel.grid(row=0, pady=15, padx=15, sticky=S)
    customtkinter.CTkButton(csframe, font=("Arial", 15), text='Open the File', command=lambda: [csframe.pack_forget(),showjson() ]).grid(row=1, column = 0,  pady=15, padx=15,sticky=S)
    customtkinter.CTkButton(csframe, font=("Arial", 15), text='Back to Menu', command=lambda: [ mainframe.pack(pady=15, padx=5),csframe.pack_forget()]).grid(row=2, sticky=S,  pady=15, padx=15)



##Main Menu
customtkinter.set_appearance_mode("System")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green
global app
app = customtkinter.CTk()
app.geometry("500x600")
app.iconbitmap("./jmmy.ico")
app.title("JMMY Delivery System")
mainframe = customtkinter.CTkFrame(app )
mainframe.pack(pady=15, padx=15)
logo = ImageTk.PhotoImage(Image.open("./jmmy.png"))

lblimage = Label(mainframe, image=logo)
lblimage.grid(row=0,pady=15, padx=15)
#logo.grid(row=1, pady=15, padx=15, sticky=S)
title = customtkinter.CTkLabel(mainframe, text="Welcome to JMMY Delivery System", font=("Arial", 17) )
title.grid(row=1, pady=15, padx=15, sticky=S)
sendbutton = customtkinter.CTkButton(mainframe,font=("Arial", 15), text="Manage Courier", command=lambda: [manacourier(),mainframe.pack_forget()])
sendbutton.grid(row=2, column = 0,  pady=15, padx=15,sticky=S)
receive = customtkinter.CTkButton(mainframe, font=("Arial", 15),text="Check Courier" , command=lambda: [checktatus()])
receive.grid(row=3, sticky=S,  pady=15, padx=15)
exitButton = customtkinter.CTkButton (mainframe, font=("Arial", 15), text="Exit",  command=app.quit)
exitButton.grid(row=4,sticky=S, pady=15, padx=15)

app.mainloop()
##call the screen function
