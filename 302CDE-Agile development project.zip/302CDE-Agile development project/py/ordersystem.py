from tkinter import *
from tkinter import filedialog
import json
import datetime
import os
from decimal import Decimal
import tkinter.messagebox
from datetime import datetime
import customtkinter
from PIL import ImageTk, Image


class quan:
    q = 0
    def localquan(self, a, pname):
        Panadol = 10000
        Famotidine = 50000
        Chiorpheniramin = 300
        Paracetamol = 5000

        if a is None:
            if pname == "Panadol" and Panadol - quan.q > 0:
                return Panadol - quan.q
            if pname=="Famotidine" and Famotidine - quan.q > 0 :
                return Famotidine - quan.q
            if pname=="Chiorpheniramin" and Chiorpheniramin - quan.q > 0 :
                return Chiorpheniramin - quan.q
            if pname=="Paracetamol" and Paracetamol - quan.q > 0 :
                return Paracetamol - quan.q
        else:
            if pname == "Panadol" and Panadol - quan.q >= 0:
                quan.q = quan.q + int(a)
                return Panadol - quan.q


            elif pname == "Famotidine" and Famotidine - quan.q >= 0:
                quan.q = quan.q + int(a)
                return Famotidine - quan.q


            elif pname == "Chiorpheniramin" and Chiorpheniramin - quan.q >= 0:
                quan.q = quan.q + int(a)
                return Chiorpheniramin - quan.q

            elif pname == "Paracetamol" and Paracetamol - quan.q >= 0:
                quan.q = quan.q + int(a)
                return Paracetamol - quan.q

            else:
                return -1



def orderform():
    def showqty(*arg):
        print(Pname.get())
        lblmsg.grid(row=9)
        lblmsg.configure(text="The Quantity is: %s" %quan.localquan(quan.q, None, Pname.get()))

    mainframe.pack_forget()
    options = ["Panadol", "Famotidine", "Chiorpheniramin", "Paracetamol"]
    orderF = customtkinter.CTkFrame(app)
    orderF.grid(row=0, pady=15, padx=20)
    selvalue = tkinter.StringVar(orderF)
    selvalue.set(options[0])#default value

    customtkinter.CTkLabel(orderF, text="Order Form", font=("Arial", 20)).grid(row=0, columnspan=2, pady=8, padx=5)

    customtkinter.CTkLabel(orderF, text="Customer Name", font=("Arial", 15)).grid(row=1, pady=5, padx=5)
    Cname = customtkinter.CTkEntry(orderF)
    Cname.grid(row=1, column=1, pady=5, padx=5)
    customtkinter.CTkLabel(orderF, text="Product Name", font=("Arial", 15)).grid(row=2, pady=5, padx=5)
    Pname = customtkinter.CTkOptionMenu(orderF,values=options, variable=selvalue,command=showqty )
    Pname.grid(row=2, column=1, pady=5, padx=5)
    #
    customtkinter.CTkLabel(orderF, text="Address", font=("Arial", 15)).grid(row=3, pady=5, padx=5)
    CAddress = customtkinter.CTkEntry(orderF)
    CAddress.grid(row=3, column=1, pady=5, padx=5)
    customtkinter.CTkLabel(orderF, text="Contact No", font=("Arial", 15)).grid(row=4, pady=5, padx=5)
    CContact = customtkinter.CTkEntry(orderF)
    CContact.grid(row=4, column=1, pady=5, padx=5)
    customtkinter.CTkLabel(orderF, text="Quantity", font=("Arial", 15)).grid(row=5)
    Quan = customtkinter.CTkEntry(orderF)
    Quan.grid(row=5, column=1, pady=5, padx=5)





    def Createjson():
        if  Quan.get() == "" or Cname.get() == "" or CAddress.get() == "" or CContact.get() == "":
            lblmsg.grid(row=9)
            lblmsg.configure(text="System MSG: Please fill data required in the form.")
        else:
            if Quan.get()=="0" or CContact.get() == "0":
                lblmsg.configure(text="System MSG: The Quantity and Contact No should not be 0.")
            else:
                if  str(Quan.get()).isnumeric() and str(CContact.get()).isnumeric():
                    status = quan.localquan(quan.q, Quan.get(), Pname.get())
                    print('Result: x' + str(status) + 'x')
                    if status < 0:
                        lblmsg.grid(row=9)
                        lblmsg.configure(text="System MSG: The product chosen is out the stock.")
                    else:
                        now = datetime.now()
                        s1 = now.strftime("%Y%m%d%H%M%S")
                        OrderNo = s1 + Cname.get()
                        lblmsg.grid_forget()
                        orderF.grid_forget()
                        filename = OrderNo + ".json"
                        obj = {
                            "OrderNumber": OrderNo,
                            "CustomerName": Cname.get(),
                            "Address": CAddress.get(),
                            "Contact": CContact.get(),
                            "ProductName": Pname.get(),
                            "Quantity": Quan.get(),
                            "DeliveryStatus": "Not Finished",
                            "Weight": "",
                            "Progress": "",
                            "Ddate": ""
                        }
                        with open(filename, "w") as out_file:
                            json.dump(obj, out_file)

                        print("order Create")
                        popup = customtkinter.CTkFrame(app)
                        popup.grid(row=0, padx=85, pady=15, sticky="WESN")
                        customtkinter.CTkLabel(popup, text='The order has been created.', font=("Arial", 15)).grid(row=0,
                                                                                                              padx=15,
                                                                                                              pady=15)
                        customtkinter.CTkButton(popup, text="Close", font=("Arial", 15),
                                                command=lambda: [orderF.grid_forget(), popup.grid_forget(),
                                                                 mainframe.pack(pady=15, padx=15)]).grid(row=1, padx=15,
                                                                                                         pady=15)
                else:
                    lblmsg.grid(row=9)
                    lblmsg.configure(text="System MSG: The Quantity and Contact No should contain number only.")
            # R = quan.localquan(quan.q,Quan.get())
            # print('Resault: x' +str(R)+'x')

    customtkinter.CTkButton(orderF, text="Create Order", command=Createjson).grid(row=8, column=0, pady=15, padx=5)
    customtkinter.CTkButton(orderF, text="Back", command=lambda: [orderF.grid_forget(), lblmsg.grid_forget(),
                                                                  mainframe.pack(pady=15, padx=15)]).grid(row=8,
                                                                                                          column=1,
                                                                                                          pady=15,
                                                                                                          padx=5)

    msgbox = LabelFrame(orderF, text="System Message", labelanchor=N, font=("Arial", 15)).grid(row=9, columnspan=2)
    lblmsg = customtkinter.CTkLabel(msgbox, text="")


def showjson():
    name = filedialog.askopenfilename(initialdir="./", filetypes={ ("JSON", "*.json")})
    if name =="": #cancel select file
        orderstatus()
    else:
        with open(name, "r") as reader:
            targetfile = json.loads(reader.read())

        showframe = customtkinter.CTkFrame(app)
        showframe.pack(pady=15, padx=5)
        customtkinter.CTkLabel(showframe, font=("Arial", 17), text="Order Detail").grid(row=0, columnspan=2, padx=5,
                                                                                        pady=10)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Order No.:").grid(row=1, column=0, padx=5, pady=5,
                                                                                      sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["OrderNumber"]).grid(row=1, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Customer Name:").grid(row=2, column=0, padx=5,
                                                                                          pady=(5, 5),
                                                                                          sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["CustomerName"]).grid(row=2, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Contact:").grid(row=3, column=0, padx=5, pady=5,
                                                                                    sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Contact"]).grid(row=3, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Product Name:").grid(row=4, column=0, padx=5,
                                                                                         pady=5,
                                                                                         sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["ProductName"]).grid(row=4, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Quantity:").grid(row=5, column=0, padx=5, pady=5,
                                                                                     sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["Quantity"]).grid(row=5, column=1)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text="Delivery Status:").grid(row=6, column=0, padx=5,
                                                                                            pady=5,
                                                                                            sticky=W)
        customtkinter.CTkLabel(showframe, font=("Arial", 15), text=targetfile["DeliveryStatus"]).grid(row=6, column=1)
        customtkinter.CTkButton(showframe, text="Back", command=lambda: [showframe.pack_forget(), orderstatus()]).grid(
            row=7, column=0, columnspan=2, pady=15, padx=15)


def orderstatus():
    mainframe.pack_forget()
    osframe = customtkinter.CTkFrame(app)
    osframe.pack(pady=15, padx=15)
    orderLabel = customtkinter.CTkLabel(osframe, text='Please Choose the Order file to review', font=("Arial", 17))
    orderLabel.grid(row=0, pady=15, padx=15, sticky=S)
    customtkinter.CTkButton(osframe, font=("Arial", 15), text='Open the File',
                            command=lambda: [osframe.pack_forget(), showjson()]).grid(row=1, column=0, pady=15, padx=15,
                                                                                      sticky=S)
    customtkinter.CTkButton(osframe, font=("Arial", 15), text='Back to Menu',
                            command=lambda: [mainframe.pack(pady=15, padx=5), osframe.pack_forget()]).grid(row=2,
                                                                                                           sticky=S,
                                                                                                           pady=15,
                                                                                                           padx=15)


customtkinter.set_appearance_mode("System")  # Modes: system (default), light, dark
customtkinter.set_default_color_theme("blue")  # Themes: blue (default), dark-blue, green
global app
app = customtkinter.CTk()
app.geometry("350x500")
app.iconbitmap("./jmmy.ico") # pls find the file path
app.title("JMMY Ordering System")
mainframe = customtkinter.CTkFrame(app)
mainframe.pack(pady=15, padx=15)
logo = ImageTk.PhotoImage(Image.open("./jmmy.ico")) # pls find the file path

lblimage = Label(mainframe, image=logo)
lblimage.grid(row=0, pady=15, padx=15)
title = customtkinter.CTkLabel(mainframe, text="Welcome to JMMY Ordering System", font=("Arial", 17))
title.grid(row=1, pady=15, padx=15, sticky=S)
sendbutton = customtkinter.CTkButton(mainframe, font=("Arial", 15), text="Create Order", command=orderform)
sendbutton.grid(row=2, column=0, pady=15, padx=15, sticky=S)
receive = customtkinter.CTkButton(mainframe, font=("Arial", 15), text="Order Status", command=lambda: [orderstatus()])
receive.grid(row=3, sticky=S, pady=15, padx=15)
exitButton = customtkinter.CTkButton(mainframe, font=("Arial", 15), text="Exit", command=app.quit)
exitButton.grid(row=4, sticky=S, pady=15, padx=15)

app.mainloop()
##start the GUI
